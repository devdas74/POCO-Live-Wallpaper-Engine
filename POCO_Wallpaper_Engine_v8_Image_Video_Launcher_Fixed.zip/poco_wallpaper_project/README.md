# POCO Live Wallpaper Engine v8 — Image + Video

Native Android live wallpaper using `WallpaperService` + Media3/ExoPlayer.

## Media
- **Add / Replace Video**: choose a video through Android's document picker.
- **Add / Replace Image**: choose JPG/JPEG, PNG, or WebP through Android's document picker.
- The selected media is copied into device-protected app storage and persists across normal app restarts and device reboots.
- Selecting new media replaces the active media type. If the engine is running, the wallpaper reloads immediately.
- Images use center + cover/crop scaling with a small overscan for subtle gyro parallax.
- Video audio tracks are disabled and volume is zero.

## Gyro
- Optional subtle rotation-vector parallax is available with **GYRO: ENABLED/DISABLED**.
- The native image renderer applies the parallax directly to the image.
- The existing direct ExoPlayer video path remains center/crop; sensor lifecycle is preserved without pretending the video surface itself is GPU-transformed.

## Controls
- **Kill Engine** persists the stopped state and releases wallpaper media resources.
- **Restart Engine** clears the stopped state and starts the selected media when a valid wallpaper surface exists.
- Wallpaper touch events are disabled.

## Important
A normal Android app cannot guarantee-kill its entire Linux application process. Kill Engine stops and releases resources owned by the wallpaper engine.
