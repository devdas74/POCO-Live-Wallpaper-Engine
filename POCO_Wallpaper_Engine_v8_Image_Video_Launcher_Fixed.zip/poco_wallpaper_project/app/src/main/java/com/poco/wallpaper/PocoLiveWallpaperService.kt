package com.poco.wallpaper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import java.io.File

class PocoLiveWallpaperService : WallpaperService() {
    companion object {
        const val ACTION_KILL_ENGINE = "com.poco.wallpaper.ACTION_KILL_ENGINE"
        const val ACTION_RESTART_ENGINE = "com.poco.wallpaper.ACTION_RESTART_ENGINE"
        const val ACTION_VIDEO_CHANGED = "com.poco.wallpaper.ACTION_VIDEO_CHANGED"
        const val ACTION_IMAGE_CHANGED = "com.poco.wallpaper.ACTION_IMAGE_CHANGED"
        const val ACTION_GYRO_CHANGED = "com.poco.wallpaper.ACTION_GYRO_CHANGED"
        private const val PREFS = "engine_state"
        private const val KEY_KILLED = "killed"
        private const val VIDEO_FILE = "selected_wallpaper_video"
        private const val IMAGE_FILE = "selected_wallpaper_image"
        private const val KEY_MEDIA_TYPE = "selected_media_type"
        private const val KEY_GYRO_ENABLED = "gyro_enabled"
        private const val MEDIA_VIDEO = "video"
        private const val MEDIA_IMAGE = "image"
        @Volatile var isKilled = false; private set
        private fun storageContext(context: Context): Context = context.createDeviceProtectedStorageContext()
        private fun prefs(context: Context) = storageContext(context).getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        fun setKilled(context: Context, killed: Boolean) { isKilled = killed; prefs(context).edit().putBoolean(KEY_KILLED, killed).apply() }
        fun readKilled(context: Context): Boolean = prefs(context).getBoolean(KEY_KILLED, false)
        fun selectedVideoFile(context: Context): File = File(storageContext(context).filesDir, VIDEO_FILE)
        fun selectedImageFile(context: Context): File = File(storageContext(context).filesDir, IMAGE_FILE)
        fun hasSelectedVideo(context: Context): Boolean = selectedVideoFile(context).let { it.isFile && it.length() > 0L }
        fun hasSelectedImage(context: Context): Boolean = selectedImageFile(context).let { it.isFile && it.length() > 0L }
        fun selectedMediaType(context: Context): String? = prefs(context).getString(KEY_MEDIA_TYPE, null)
        fun setSelectedMediaType(context: Context, type: String) = prefs(context).edit().putString(KEY_MEDIA_TYPE, type).apply()
        fun isGyroEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_GYRO_ENABLED, true)
        fun setGyroEnabled(context: Context, enabled: Boolean) = prefs(context).edit().putBoolean(KEY_GYRO_ENABLED, enabled).apply()
    }

    override fun onCreate() { super.onCreate(); isKilled = readKilled(this) }
    override fun onCreateEngine(): Engine = WallpaperEngine()

    inner class WallpaperEngine : Engine() {
        private var exoPlayer: ExoPlayer? = null
        private var bitmap: android.graphics.Bitmap? = null
        private var receiver: BroadcastReceiver? = null
        private var receiverRegistered = false
        private var destroyed = false
        private var visible = true
        private var gyro: WallpaperParallaxController? = null
        private var px = 0f
        private var py = 0f
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(false)
            registerEngineReceiver()
        }

        private fun registerEngineReceiver() {
            if (receiverRegistered) return
            receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    when (intent.action) {
                        ACTION_KILL_ENGINE -> killEngine()
                        ACTION_RESTART_ENGINE -> restartEngine()
                        ACTION_VIDEO_CHANGED, ACTION_IMAGE_CHANGED -> reloadMediaIfAllowed()
                        ACTION_GYRO_CHANGED -> updateGyroState()
                    }
                }
            }
            val filter = IntentFilter().apply {
                addAction(ACTION_KILL_ENGINE); addAction(ACTION_RESTART_ENGINE)
                addAction(ACTION_VIDEO_CHANGED); addAction(ACTION_IMAGE_CHANGED); addAction(ACTION_GYRO_CHANGED)
            }
            ContextCompat.registerReceiver(this@PocoLiveWallpaperService, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            if (!isEngineKilled()) { initMedia(holder); updateGyroState() }
        }
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            if (isImageMode()) drawImage(holder)
        }
        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            releaseMedia(); stopGyro(); super.onSurfaceDestroyed(holder)
        }
        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible); this.visible = visible
            if (isEngineKilled()) return
            if (visible) { if (isImageMode()) drawImage(surfaceHolder); else exoPlayer?.play() }
            else exoPlayer?.pause()
        }
        private fun killEngine() { setKilled(this@PocoLiveWallpaperService, true); releaseMedia(); stopGyro() }
        private fun restartEngine() {
            if (destroyed) return
            setKilled(this@PocoLiveWallpaperService, false)
            surfaceHolder?.takeIf { it.surface.isValid }?.let { initMedia(it); updateGyroState() }
        }
        private fun reloadMediaIfAllowed() {
            if (destroyed || isEngineKilled()) return
            surfaceHolder?.takeIf { it.surface.isValid }?.let { releaseMedia(); initMedia(it); updateGyroState() }
        }
        private fun isEngineKilled() = isKilled || readKilled(this@PocoLiveWallpaperService)
        private fun isImageMode() = selectedMediaType(this@PocoLiveWallpaperService) == MEDIA_IMAGE && hasSelectedImage(this@PocoLiveWallpaperService)

        private fun initMedia(holder: SurfaceHolder) {
            if (isEngineKilled() || !holder.surface.isValid) return
            if (isImageMode()) { loadBitmap(); drawImage(holder); return }
            val videoFile = selectedVideoFile(this@PocoLiveWallpaperService)
            if (!videoFile.isFile || videoFile.length() <= 0L) return
            val trackSelector = DefaultTrackSelector(this@PocoLiveWallpaperService).apply {
                parameters = buildUponParameters().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
            }
            exoPlayer = ExoPlayer.Builder(this@PocoLiveWallpaperService).setTrackSelector(trackSelector).build().apply {
                setMediaItem(MediaItem.fromUri(Uri.fromFile(videoFile)))
                repeatMode = Player.REPEAT_MODE_ONE; volume = 0f
                videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                setVideoSurfaceHolder(holder); prepare(); playWhenReady = visible
            }
        }
        private fun loadBitmap() {
            bitmap?.recycle(); bitmap = BitmapFactory.decodeFile(selectedImageFile(this@PocoLiveWallpaperService).absolutePath)
        }
        private fun drawImage(holder: SurfaceHolder?) {
            val b = bitmap ?: return
            val surface = holder?.surface ?: return
            if (!surface.isValid) return
            val canvas: Canvas = try { surface.lockCanvas(null) } catch (_: Exception) { null } ?: return
            try {
                canvas.drawColor(android.graphics.Color.BLACK)
                val sw = canvas.width.toFloat(); val sh = canvas.height.toFloat()
                val scale = maxOf(sw / b.width, sh / b.height) * 1.06f
                val dw = b.width * scale; val dh = b.height * scale
                val extraX = (dw - sw) / 2f; val extraY = (dh - sh) / 2f
                val maxShiftX = extraX * 0.35f; val maxShiftY = extraY * 0.35f
                val left = (sw - dw) / 2f + px * maxShiftX
                val top = (sh - dh) / 2f + py * maxShiftY
                canvas.drawBitmap(b, null, RectF(left, top, left + dw, top + dh), paint)
            } finally { holder?.unlockCanvasAndPost(canvas) }
        }
        private fun updateGyroState() {
            if (destroyed || isEngineKilled() || !isGyroEnabled(this@PocoLiveWallpaperService)) { stopGyro(); return }
            if (gyro == null) {
                gyro = WallpaperParallaxController(this@PocoLiveWallpaperService) { x, y ->
                    px = x; py = y
                    if (isImageMode() && visible && !destroyed) drawImage(surfaceHolder)
                }
                gyro?.start()
            }
        }
        private fun stopGyro() { gyro?.stop(); gyro = null; px = 0f; py = 0f; if (isImageMode() && visible) drawImage(surfaceHolder) }
        private fun releaseMedia() {
            exoPlayer?.let { it.playWhenReady = false; it.pause(); it.clearVideoSurface(); it.stop(); it.release() }
            exoPlayer = null; bitmap?.recycle(); bitmap = null
        }
        override fun onDestroy() {
            destroyed = true; releaseMedia(); stopGyro()
            if (receiverRegistered) { receiver?.let { try { unregisterReceiver(it) } catch (_: IllegalArgumentException) {} }; receiver = null; receiverRegistered = false }
            super.onDestroy()
        }
    }
}

private class WallpaperParallaxController(context: Context, private val onParallax: (Float, Float) -> Unit) : android.hardware.SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as android.hardware.SensorManager
    private val sensor = sensorManager.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR)
    private val matrix = FloatArray(9); private val orientation = FloatArray(3)
    private var sx = 0f; private var sy = 0f
    fun start() { sensor?.let { sensorManager.registerListener(this, it, android.hardware.SensorManager.SENSOR_DELAY_GAME) } }
    fun stop() { sensorManager.unregisterListener(this); sx = 0f; sy = 0f; onParallax(0f, 0f) }
    override fun onSensorChanged(event: android.hardware.SensorEvent) {
        if (event.sensor.type != android.hardware.Sensor.TYPE_ROTATION_VECTOR) return
        android.hardware.SensorManager.getRotationMatrixFromVector(matrix, event.values)
        android.hardware.SensorManager.getOrientation(matrix, orientation)
        val tx = (orientation[2] / 0.65f).coerceIn(-1f, 1f)
        val ty = (orientation[1] / 0.65f).coerceIn(-1f, 1f)
        sx += (tx - sx) * 0.10f; sy += (ty - sy) * 0.10f; onParallax(sx, sy)
    }
    override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) = Unit
}
