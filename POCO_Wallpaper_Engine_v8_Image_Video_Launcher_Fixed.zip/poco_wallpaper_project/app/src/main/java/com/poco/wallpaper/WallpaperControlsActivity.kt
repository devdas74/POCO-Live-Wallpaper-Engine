package com.poco.wallpaper

import android.app.Activity
import android.content.Intent
import android.content.ComponentName
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.util.concurrent.Executors

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
class WallpaperControlsActivity : AppCompatActivity() {

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var videoStatus: TextView
    private lateinit var killBtn: Button
    private lateinit var restartBtn: Button
    private lateinit var videoBtn: Button
    private lateinit var imageBtn: Button
    private lateinit var mediaStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var gyroBtn: Button
    private lateinit var setWallpaperBtn: Button

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) importImage(uri)
    }

    private val pickVideo = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) importVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#CC000000"))
            setPadding(50, 90, 50, 90)
        }

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(0, 0, 0, 24)
        }

        videoStatus = TextView(this).apply {
            setTextColor(Color.LTGRAY)
            textSize = 15f
            setPadding(0, 0, 0, 30)
        }

        imageBtn = Button(this).apply {
            text = "ADD / REPLACE IMAGE"
            setTextColor(Color.WHITE)
            setOnClickListener { pickImage.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }
        }

        videoBtn = Button(this).apply {
            text = "ADD / REPLACE VIDEO"
            setTextColor(Color.WHITE)
            setOnClickListener {
                pickVideo.launch(arrayOf("video/*"))
            }
        }

        gyroBtn = Button(this).apply {
            text = if (PocoLiveWallpaperService.isGyroEnabled(this@WallpaperControlsActivity)) "GYRO: ENABLED" else "GYRO: DISABLED"
            setOnClickListener { toggleGyro() }
        }

        setWallpaperBtn = Button(this).apply {
            text = "SET LIVE WALLPAPER"
            setTextColor(Color.WHITE)
            setOnClickListener { openWallpaperPicker() }
        }

        progress = ProgressBar(this).apply {
            visibility = ProgressBar.GONE
        }

        killBtn = Button(this).apply {
            text = "KILL ENGINE"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.RED)
            setOnClickListener {
                sendEngineCommand(PocoLiveWallpaperService.ACTION_KILL_ENGINE)
                refreshState()
            }
        }

        restartBtn = Button(this).apply {
            text = "RESTART ENGINE"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#00C853"))
            setOnClickListener {
                sendEngineCommand(PocoLiveWallpaperService.ACTION_RESTART_ENGINE)
                refreshState()
            }
        }

        root.addView(status, matchParams())
        root.addView(videoStatus, matchParams())
        root.addView(videoBtn, matchParams())
        root.addView(imageBtn, matchParams())
        root.addView(gyroBtn, matchParams())
        root.addView(setWallpaperBtn, matchParams())
        root.addView(progress, centeredParams())
        root.addView(killBtn, matchParams())
        root.addView(restartBtn, matchParams())

        setContentView(root)
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) refreshState()
    }

    private fun refreshState() {
        val killed = PocoLiveWallpaperService.readKilled(this)
        status.text = if (killed) {
            "ENGINE STATUS: STOPPED"
        } else {
            "ENGINE STATUS: RUNNING"
        }

        val file = PocoLiveWallpaperService.selectedVideoFile(this)
        val image = PocoLiveWallpaperService.selectedImageFile(this)
        val type = PocoLiveWallpaperService.selectedMediaType(this)
        videoStatus.text = when {
            type == "image" && image.exists() && image.length() > 0L -> "WALLPAPER IMAGE: ${formatFileName(image)}"
            file.exists() && file.length() > 0L -> "WALLPAPER VIDEO: ${formatFileName(file)}"
            else -> "WALLPAPER MEDIA: NONE — add an image or video"
        }

        killBtn.isEnabled = !killed
        restartBtn.isEnabled = killed
        if (::gyroBtn.isInitialized) {
            gyroBtn.text = if (PocoLiveWallpaperService.isGyroEnabled(this)) "GYRO: ENABLED" else "GYRO: DISABLED"
        }
    }

    private fun openWallpaperPicker() {
        val component = ComponentName(this, PocoLiveWallpaperService::class.java)
        try {
            startActivity(Intent("android.service.wallpaper.CHANGE_LIVE_WALLPAPER").apply {
                putExtra("android.service.wallpaper.extra.LIVE_WALLPAPER_COMPONENT", component)
            })
        } catch (_: Exception) {
            startActivity(Intent("android.service.wallpaper.LIVE_WALLPAPER_CHOOSER"))
        }
    }

    private fun toggleGyro() {
        val enabled = !PocoLiveWallpaperService.isGyroEnabled(this)
        PocoLiveWallpaperService.setGyroEnabled(this, enabled)
        val intent = Intent(PocoLiveWallpaperService.ACTION_GYRO_CHANGED).apply { setPackage(packageName) }
        sendBroadcast(intent)
        refreshState()
    }

    private fun importVideo(sourceUri: Uri) {
        setBusy(true)
        videoStatus.text = "WALLPAPER VIDEO: importing..."

        ioExecutor.execute {
            val destination = PocoLiveWallpaperService.selectedVideoFile(this)
            val temp = File(destination.parentFile, "${destination.name}.part")
            var success = false

            try {
                contentResolver.openInputStream(sourceUri)?.use { input ->
                    temp.outputStream().use { output ->
                        input.copyTo(output, DEFAULT_BUFFER_SIZE)
                    }
                } ?: throw IllegalStateException("Unable to open selected video")

                if (temp.length() <= 0L) throw IllegalStateException("Selected video is empty")
                if (destination.exists()) destination.delete()
                if (!temp.renameTo(destination)) {
                    temp.copyTo(destination, overwrite = true)
                    temp.delete()
                }
                success = true
            } catch (_: Exception) {
                temp.delete()
            }

            runOnUiThread {
                setBusy(false)
                if (success) {
                    PocoLiveWallpaperService.setSelectedMediaType(this, "video")
                    sendEngineCommand(PocoLiveWallpaperService.ACTION_VIDEO_CHANGED)
                    videoStatus.text = "WALLPAPER VIDEO: ${formatFileName(destination)}"
                } else {
                    refreshState()
                    videoStatus.text = "WALLPAPER VIDEO: import failed"
                }
            }
        }
    }

    private fun importImage(sourceUri: Uri) {
        setBusy(true)
        videoStatus.text = "WALLPAPER IMAGE: importing..."
        ioExecutor.execute {
            val destination = PocoLiveWallpaperService.selectedImageFile(this)
            val temp = File(destination.parentFile, "${destination.name}.part")
            var success = false
            try {
                contentResolver.openInputStream(sourceUri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output, DEFAULT_BUFFER_SIZE) } }
                    ?: throw IllegalStateException("Unable to open selected image")
                if (temp.length() <= 0L) throw IllegalStateException("Selected image is empty")
                if (destination.exists()) destination.delete()
                if (!temp.renameTo(destination)) { temp.copyTo(destination, overwrite = true); temp.delete() }
                success = true
            } catch (_: Exception) { temp.delete() }
            runOnUiThread {
                setBusy(false)
                if (success) {
                    PocoLiveWallpaperService.setSelectedMediaType(this, "image")
                    sendEngineCommand(PocoLiveWallpaperService.ACTION_IMAGE_CHANGED)
                    refreshState()
                } else { videoStatus.text = "WALLPAPER IMAGE: import failed" }
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        videoBtn.isEnabled = !busy
        imageBtn.isEnabled = !busy
        killBtn.isEnabled = !busy && !PocoLiveWallpaperService.readKilled(this)
        restartBtn.isEnabled = !busy && PocoLiveWallpaperService.readKilled(this)
        progress.visibility = if (busy) ProgressBar.VISIBLE else ProgressBar.GONE
    }

    private fun formatFileName(file: File): String =
        if (file.length() > 1024L * 1024L * 1024L) {
            "selected video (${file.length() / (1024L * 1024L * 1024L)} GB)"
        } else {
            "selected video (${file.length() / (1024L * 1024L)} MB)"
        }

    private fun sendEngineCommand(action: String) {
        val intent = Intent(action).apply { setPackage(packageName) }
        sendBroadcast(intent)
    }

    override fun onDestroy() {
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    private fun matchParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 16 }

    private fun centeredParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.WRAP_CONTENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.CENTER_HORIZONTAL
        bottomMargin = 16
    }
}



/** Persistent position model for the movable Interactive Island control. */
private object IslandPositionStore {
    private const val PREFS = "wallpaper_controls"
    private const val ISLAND_X = "island_x"
    private const val ISLAND_Y = "island_y"

    fun save(context: android.content.Context, x: Int, y: Int) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putInt(ISLAND_X, x).putInt(ISLAND_Y, y).apply()
    }

    fun load(context: android.content.Context): android.graphics.Point? {
        val p = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        if (!p.contains(ISLAND_X) || !p.contains(ISLAND_Y)) return null
        return android.graphics.Point(p.getInt(ISLAND_X, 0), p.getInt(ISLAND_Y, 0))
    }
}
